
// Creo Array con 15 colores diferentes
let coloresTodos = [
    "rgb(255, 0, 0)",     // Rojo
    "rgb(0, 255, 0)",     // Verde
    "rgb(0, 0, 255)",     // Azul
    "rgb(255, 255, 0)",   // Amarillo
    "rgb(255, 0, 255)",   // Magenta
    "rgb(0, 255, 255)",   // Cian
    "rgb(255, 165, 0)",   // Naranja
    "rgb(128, 0, 128)",   // Morado
    "rgb(255, 192, 203)", // Rosa
    "rgb(0, 128, 128)",   // Verde azulado
    "rgb(128, 128, 0)",   // Verde oliva
    "rgb(128, 0, 0)",     // Marrón
    "rgb(0, 0, 128)",     // Azul marino
    "rgb(128, 128, 128)", // Gris
    "rgb(0, 0, 0)"        // Negro
];

let colorBlancos = `rgba(79, 34, 34, 0.171)`;

// Exporto las variables
export {
    coloresTodos,
    colorBlancos,
};
