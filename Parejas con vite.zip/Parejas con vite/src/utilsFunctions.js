// Archivo donde acumulo las funciones utiles

// Importo las variables necesarias
import { 
    colorBlancos,
    coloresTodos,
} from "./variables";



// Funcion de crear tablero
function crearTablero() {
    let cols;
    let rows;

        // Pedimos por pantalla ñlas filas y columnas
    cols = parseInt(prompt("numero de columnas"));
    rows = parseInt(prompt("numero de filas"));
    // Si las cartar no son pares pedir de nuevo
    while ((cols * rows) % 2 !== 0) {
        alert("Las cartas tienen que ser pares repite de nuevo");
        cols = parseInt(prompt("numero de columnas"));
        rows = parseInt(prompt("numero de filas"));
    }
    // creo la variable cuadricula
    const cuadricula = document.getElementsByClassName("game");

    // Recorro todo la cuadricula creando el numero de cajas pertinente
    for (let col = 0; col < cols; col ++) {;
        for (let row =0; row < rows; row ++) {
        let box = document.createElement("div");
        box.dataset.open = 0;
        cuadricula[0].append(box);
        }
    }
}

// funcion para asignar colores al array de las parejas
function asignarColores(array) {
    // Creo una variable con el total de las parejas que hay en la cuadricula
    let parejas = array.length / 2
    
    // Recorro el array nuevo y le asigno los colores en todas las cajas
    for (let numCaja = 0; numCaja < (parejas *2); numCaja = numCaja + 2) {
        array[numCaja].style.backgroundColor = coloresTodos[numCaja] 
        array[numCaja].dataset.bg = coloresTodos[numCaja];
        array[numCaja + 1].style.backgroundColor = coloresTodos[numCaja];
        array[numCaja + 1].dataset.bg = coloresTodos[numCaja];
        array[numCaja].dataset.open = 0;
        array[numCaja + 1].dataset.open = 0;
    }
    return array
}

// Funcion para barajar el Nodelist del array con las cajas
function barajarArray() {
    const list = document.querySelector('section');
    for (let box = list.children.length; box >= 0; box--) {
        list.appendChild(list.children[Math.random() * box | 0]);
    }
};


// funcion reset colores
function resetColores() {
    let todosDivs = document.querySelectorAll("div");
    // Recorro todas las cajas y borro los colores predefinidos anteriormente
    for (let divs of todosDivs) {
        divs.style.backgroundColor = colorBlancos;
        divs.dataset.open = 0;
    }
}

// Exporto las funciones
export {
    resetColores,
    crearTablero,
    asignarColores,
    barajarArray,
}