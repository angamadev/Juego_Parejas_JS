// importo los estilos
import "/sass/main.scss";

// importo las funciones mas utiles
import { 
    resetColores,
    crearTablero,
    asignarColores,
    barajarArray
} from "./utilsFunctions.js";

// importo pareja de los eventos
import {
    pareja
} from "./evento.js";

// Exporto el array de las cajas
export {arrayBoxes}

// Pedimos la funcion de crear tablero
crearTablero();

// Asignamos colores a el array de las boxes
let arrayBoxes = document.querySelectorAll("div");
asignarColores(arrayBoxes);

// // Reseteo los colores
resetColores();

//  Hago nuevo array y barajo
barajarArray();

// Hago bucle para ejecutar cada evento
for (let div of arrayBoxes) {
    div.addEventListener("click", pareja); 
}



